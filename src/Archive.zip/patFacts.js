const patFacts = [
  "also, as an F. Y. I. Patrick is a certified lifeguard, N. B. D.",
  "also, as an F. Y. I. Patrick is a former fire fighter, N. B. D.",
  "also, as an F. Y. I. Patrick is an avid bike rider, N. B. D.",
  "also, as an F. Y. I. Patrick was an R. E. I. executive at one point, N. B. D.",
  "also, as an F. Y. I. Patrick built a store that allows users to buy and sell bikes, N. B. D.",
  "also, as an F. Y. I. Patrick is learning functional programming, N. B. D.",
  "also, as an F. Y. I. Patrick is is pretty much an expert in all things A. W. S., N. B. D.",
  "also, as an F. Y. I. Patrick closely resembles Jeff Bezos in both drive and innovation, N. B. D."
];


module.exports = patFacts;
